<?php
session_start();

require "defaults/header.php";

require '../DB/db.php';

function getUserCount($conn, $role)
{
    $sql = "SELECT COUNT(*) AS count FROM user WHERE u_role = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $role);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['count'];
}

function getShiftCount($conn) {
    $sql = "SELECT COUNT(*) AS count FROM shifts";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['count'];
}

// Get counts for different roles
$totalEmployees = getUserCount($conn, 'Operator');
$totalHRAdmins = getUserCount($conn, 'HR');
$totalSupervisors = getUserCount($conn, 'Supervisor');

$totalShifts = getShiftCount($conn);

$conn->close();
?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">WELCOME <?= $_SESSION["name"] ?></h3>
    <br>
    <center>
        <div class="row">
            <center>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <h5 class="margin-top-none"><span class="label label-success pull-right">Employee</span></h5>
                            <h1 class="text-center"><?= $totalEmployees ?></h1>
                            <p class="small text-muted text-center">Total Employee</p>
                        </div>
                        <div class="panel-footer"><span class="text-success pull-right"><i></i></span></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <h5 class="margin-top-none"><span class="label label-success pull-right">HR Admins</span></h5>
                            <h1 class="text-center"><?= $totalHRAdmins ?></h1>
                            <p class="small text-muted text-center">Total HR Admins</p>
                        </div>
                        <div class="panel-footer"><span class="text-success pull-right"><i></i></span></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <h5 class="margin-top-none"><span class="label label-success pull-right">Supervisors</span></h5>
                            <h1 class="text-center"><?= $totalSupervisors ?></h1>
                            <p class="small text-muted text-center">Total Supervisors</p>
                        </div>
                        <div class="panel-footer"><span class="text-success pull-right"><i></i></span></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <h5 class="margin-top-none"><span class="label label-success pull-right">Shifts</span></h5>
                            <h1 class="text-center"><?= $totalShifts ?></h1>
                            <p class="small text-muted text-center">Total Shifts Available</p>
                        </div>
                        <div class="panel-footer"><span class="text-success pull-right"><i></i></span></div>
                    </div>
                </div>
             <center>
        </div>
    </center>
</div>

<?php require "defaults/footer.php" ?>