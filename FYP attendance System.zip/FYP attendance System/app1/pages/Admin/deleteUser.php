<?php

// Include your database connection
require '../DB/db.php';

// Check if the user ID is set in the URL
if (isset($_GET['u_id'])) {
    $userId = $_GET['u_id'];
    $sql = "DELETE FROM user WHERE u_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId); // Assuming u_id is an integer
    $stmt->execute();
    $stmt->close();
    $conn->close();
    header("Location: user.php");
    exit();
} else {
    // Handle the case where the user ID is not set in the URL
    echo "Invalid request. User ID not provided.";
    exit();
}
