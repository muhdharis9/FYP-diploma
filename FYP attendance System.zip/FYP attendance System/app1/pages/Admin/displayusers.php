<?php

// Include your database connection
require '../DB/db.php';

// Fetch data from the "user" table
$sql = "SELECT u_id, u_Name, u_staff_ID, u_role, u_Shift ,u_IC_Number FROM user";
$result = $conn->query($sql);

?>

<?php require "defaults/header.php" ?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">DISPLAY USERS</h3>
    <br>
    <div class="row">

        <br>
        <br>
        <div class="panel panel-default mt-5">
        <table class="table table-striped">
         <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <colgroup>
            <col style="width: 5%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
            <!-- Adjust the width as needed -->
        </colgroup>
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Staff ID</th>
                <th>IC Number</th>
                <th>Role</th>
                <th>Shift Name</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                $i=1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<th scope='row'>" . $i . "</th>";
                    echo "<td>" . $row["u_Name"] . "</td>";
                    echo "<td>" . $row["u_staff_ID"] . "</td>";
                    echo "<td>" . $row["u_IC_Number"] . "</td>";
                    echo "<td>" . $row["u_role"] . "</td>";
                    echo "<td>" . $row["u_Shift"] . "</td>";
                    echo "</tr>";
                    $i++;
                }
            } else {
                echo "<tr><td colspan='5'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
        </div>
    </div>
</div>

<?php require "defaults/footer.php"?>