<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Attendance System</title>
    <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="../favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="../favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="../favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="../favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="../favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#2e353b">
    <meta name="msapplication-TileImage" content="/mstile-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap Core CSS -->
    <link rel='stylesheet' href='../../../bower_components/bootstrap/dist/css/bootstrap.min.css'>


    <!-- Dashboard Theme CSS -->
    <link rel='stylesheet' href='../../styles/styles-theme.css'>

    <!-- MetisMenu CSS -->
    <link rel='stylesheet' href='../../../bower_components/metisMenu/dist/metisMenu.min.css'>

    <!-- Fonts Awesome CSS -->
    <link rel='stylesheet' href='../font-awesome-4.4.0/css/font-awesome.min.css'>

    <!-- Chartlist-js -->
    <link rel='stylesheet' href='../../../bower_components/chartist/dist/scss/chartist.css'>
    <link rel='stylesheet' href='../../styles/chartist-settings-index.css'>



    <!-- Hammer reload -->
    <script>
        setInterval(function() {
            try {
                if (typeof ws != 'undefined' && ws.readyState == 1) {
                    return true;
                }
                ws = new WebSocket('ws://' + (location.host || 'localhost').split(':')[0] + ':35353')
                ws.onopen = function() {
                    ws.onclose = function() {
                        document.location.reload()
                    }
                }
                ws.onmessage = function() {
                    var links = document.getElementsByTagName('link');
                    for (var i = 0; i < links.length; i++) {
                        var link = links[i];
                        if (link.rel === 'stylesheet' && !link.href.match(/typekit/)) {
                            href = link.href.replace(/((&|\?)hammer=)[^&]+/, '');
                            link.href = href + (href.indexOf('?') >= 0 ? '&' : '?') + 'hammer=' + (new Date().valueOf());
                        }
                    }
                }
            } catch (e) {}
        }, 1000)
    </script>
    <!-- /Hammer reload -->

</head>

<body>
    <div id="wrapper">
        <div class="clearfix">
            <div id="main_sidebar">
                <div class="sidebar_inner">
                    <div class="sidebar-custom navbar-inverse sidebar" role="navigation">
                        <div class="sidebar-nav navbar-collapse">
                            <div class="side_logo text-center sidebar-background">
                                <a href="#">
                           
                                    <span style="color: white;margin-top:210px;font-size:15px;">- COMPANY -</h6>
                                </a>
                            </div>
                            <ul class="nav" id="side-menu">
                                <li class="small-text-menu hide_el">
                                    Navigation</li>
                                <li class='current-parent current'>
                                    <a class='current-parent current' href="index.php" data-toggle="side_tooltip" data-placement="right" title="Start"><i class="fa fa-home fa-fw"></i> <span class="menu_title">Dashboard</span></a>
                                </li>
                                <li>
                                    <a href="#" data-toggle="side_tooltip_offset" data-placement="right" title="Interface"><span class="fa arrow"></span><i class="fa fa-male"></i> <span class="menu_title">User Management</span></a>
                                    <ul class="nav nav-second-level">
                                        <li class='current'>
                                            <a class='current' href="user.php">Manage Users</a>
                                        </li>
                                        <li>
                                            <a href="displayusers.php">All Users</a>
                                        </li>






                                    </ul>
                        </div>
                        <!-- /.sidebar-collapse -->
                    </div>
                    <!-- /.navbar-static-side -->
                </div>
            </div>
            <div id="main-content">
                <!-- START Navbar Default -->
                <nav class="navbar navbar-default navbar-static-top hidden-xs">
                    <div class="navbar-header">
                        <div class="container-fluid">
                            <div class="navbar-header hidden-lg hidden-md hidden-sm">
                            </div>
                        </div>
                    </div>
                    <!-- /.navbar-header -->
                    
                    <ul class="nav navbar-top-links navbar-right mt-5">


                        <li>
                        <button class="btn btn-outline btn-danger" role="button" aria-haspopup="true" aria-expanded="false" onclick="confirmLogout()" style="width: 150px; margin-top: 6px;">
                                Log Out
                            </button>

                        </li>
                    </ul>
                    <!-- /.navbar-top-links -->
                </nav>
                <!-- START Navbar Inverse -->
                <nav class="navbar navbar-inverse navbar-static-top hidden-lg hidden-md hidden-sm">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-i-tz5">
                            <i class="fa fa-list"></i>
                        </button>
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-user">
                            <span class="sr-only">Toggle navigation</span>
                            <img src="https://s3.amazonaws.com/uifaces/faces/twitter/soyjavi/24.jpg" class="img-circle avatar-height-20" alt="Menu">
                        </button>
                        <div class="container-fluid">
                            <div class="navbar-header hidden-lg hidden-md hidden-sm">
                                <a class="navbar-brand" href="#"> <img alt="Sumea Theme" src="../images/sumea-horizontal-logo-inverse.svg"></a>
                            </div>
                        </div>
                    </div>
                    <!-- /.navbar-header -->

                    <!-- Start Menu Mobile "User", "Messages" and "Notifications -->

                    <!-- /.navbar-top-links -->
                </nav>