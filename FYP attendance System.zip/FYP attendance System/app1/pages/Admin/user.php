<?php

// Include your database connection
require '../DB/db.php';

// Fetch data from the "user" table
$sql = "SELECT u_id, u_Name, u_staff_ID, u_role, u_Shift FROM user";
$result = $conn->query($sql);

?>

<?php require "defaults/header.php" ?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">USER MANAGEMENT</h3>
    <br>
    <div class="row">

        <a type="button" class="btn btn-primary" href="addNew.php"> Add New User +</a>
        <br>
        <br>
        <div class="panel panel-default mt-5">
        <table class="table table-striped">
         <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <colgroup>
                    <col style="width: 5%;">
                    <col style="width: 25%;">
                    <col style="width: 15%;">
                    <col style="width: 20%;">
                    <col style="width: 15%;">
                    <col style="width: 25%;">
                    <!-- Adjust the width as needed -->
                </colgroup>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Staff ID</th>
                        <th>Role</th>
                        <th>Shift</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        // Output data of each row
                        $i = 1;
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<th scope='row'>" . $i . "</th>";
                            echo "<td>" . $row["u_Name"] . "</td>";
                            echo "<td>" . $row["u_staff_ID"] . "</td>";
                            echo "<td>" . $row["u_role"] . "</td>";
                            echo "<td>" . $row["u_Shift"] . "</td>";
                            echo "<td>
                            <a href='editUser.php?u_id=" . $row["u_id"] . "' class='btn btn-sm btn-warning'>
                            Edit
                        </a>
                            <button class='btn btn-sm btn-danger' onclick='deleteUser(" . $row["u_id"] . ")'>
                                Delete
                            </button>
                        </td>";
                            echo "</tr>";
                            $i++;
                        }
                    } else {
                        echo "<tr><td colspan='5'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    function deleteUser(userId) {
        var confirmation = confirm("Are you sure you want to delete this user?");
        if (confirmation) {
            // If the user clicks "OK", redirect to a delete script or perform AJAX delete
            window.location.href = "deleteUser.php?u_id=" + userId;
        }
    }
</script>
<?php require "defaults/footer.php" ?>