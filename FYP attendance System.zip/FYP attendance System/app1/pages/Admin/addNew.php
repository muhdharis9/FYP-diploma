<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["save"])) {

    require '../DB/db.php';
    $name = $_POST["name"];
    $position = $_POST["position"];
    $icNumber = $_POST["icNumber"];
    $employeeID = $_POST["employeeID"];
    $assignTo = $_POST["assignTo"];
    $password = $_POST["password"];

    $employeeID = strtoupper($employeeID);

    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $error = "Name should contain only alphabets.";
    } else {
        // Convert name to uppercase
        $name = strtoupper($name);
    }
    // Validate IC Number (exactly 12 digits)
    if (!preg_match("/^\d{12}$/", $icNumber)) {
        $error = "IC Number should be exactly 12 digits.";
    }
    // If there are no errors, proceed with database insertion
    if (!isset($error)) {
    // SQL statement with placeholders
    $sql = "INSERT INTO user (u_Name, u_role, u_IC_Number, u_staff_ID, 	u_Shift, u_Password) VALUES (?, ?, ?, ?, ?, ?)";
    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);
    // Bind parameters
    $stmt->bind_param("ssssss", $name, $position, $icNumber, $employeeID, $assignTo, $password);
    // Execute the prepared statement
    $stmt->execute();
    // Close the statement
    $stmt->close();
    // Close the database connection
    $conn->close();
    // Optionally, redirect the user to another page after successful insertion
    $success = "User Successfully added";
    }
}

require '../DB/db.php';
$sqlShifts = "SELECT s_ShiftType , s_Name FROM shifts";
$resultShifts = $conn->query($sqlShifts);

// Check for errors during query execution
if (!$resultShifts) {
    die("Error: " . $conn->error);
}

?>


<?php require "defaults/header.php" ?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">ADD USER </h3>
    <br>
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">
                <p class="text-uppercase text-muted small"><strong>New User</strong>
                </p>
                <div class="row">
                    <div class="col-md-12">
                    <?php if (isset($error)) : ?>
                            <p style="color: red;"><?php echo $error; ?></p>
                        <?php endif; ?>

                        <?php if (isset($success)) : ?>
                            <p style="color: green;"><?php echo $success; ?></p>
                        <?php endif; ?>
                        <form class="form-horizontal" action="" method="POST">
                            <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Name:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="position" class="col-sm-2 control-label">Position:</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="position" name="position">
                                        <option>Operator</option>
                                        <option>Supervisor</option>
                                        <option>HR</option>
                                      
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="icNumber" class="col-sm-2 control-label">IC Number:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="icNumber" name="icNumber" placeholder="Enter IC Number">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="employeeID" class="col-sm-2 control-label">Employee ID:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="employeeID" name="employeeID" placeholder="Enter Employee ID">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="assignTo" class="col-sm-2 control-label">Assign to:</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="assignTo" name="assignTo">
                                        <?php
                                        // Check if there are rows in the result set
                                        if ($resultShifts->num_rows > 0) {
                                            // Output data of each row
                                            while ($rowShift = $resultShifts->fetch_assoc()) {
                                                // Use shift_id as the value and shift_name as the display text for each option
                                                echo "<option value='" . $rowShift["s_Name"] . "'>" . $rowShift["s_Name"] . "</option>";
                                            }
                                        } else {
                                            echo "<option>No shifts available</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password" class="col-sm-2 control-label">Password:</label>
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-6">
                                    <button type="submit" class="btn btn-success" name="save">Save</button>
                                    <a type="button" class="btn btn-danger" href="user.php">Back</a>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php require "defaults/footer.php" ?>