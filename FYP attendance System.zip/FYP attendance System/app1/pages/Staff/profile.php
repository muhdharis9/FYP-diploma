<?php session_start();

date_default_timezone_set('Asia/Kuala_Lumpur');


require '../DB/db.php';

$error = $success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["change-password"])) {
        $currentPassword = $_POST["current-password"];
        $newPassword = $_POST["new-password"];
        $confirmNewPassword = $_POST["confirm-new-password"];

        // Validate the current password
        $sql = "SELECT u_Password FROM user WHERE u_staff_ID = ?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $error = "Error in preparing the statement: " . $conn->error;
        } else {
            $stmt->bind_param("s", $_SESSION["staffid"]);
            $stmt->execute();
            $stmt->bind_result($storedPassword);
            $stmt->fetch();
            $stmt->close();

            if ($currentPassword !== $storedPassword) {
                $error = "Current password is incorrect.";
            } elseif ($newPassword !== $confirmNewPassword) {
                $error = "New password and confirm password do not match.";
            } else {
                // Update the password in the database (without password_hash)
                $updateSql = "UPDATE user SET u_Password = ? WHERE u_staff_ID = ?";
                $updateStmt = $conn->prepare($updateSql);

                if (!$updateStmt) {
                    $error = "Error in preparing the update statement: " . $conn->error;
                } else {
                    $updateStmt->bind_param("ss", $newPassword, $_SESSION["staffid"]);

                    if ($updateStmt->execute()) {
                        $success = "Password changed successfully.";
                    } else {
                        $error = "Error updating password: " . $conn->error;
                    }

                    $updateStmt->close();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('../../images/backg.jpg');
            /* Replace with the path to your background image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            /* Fixed to prevent scrolling */
        }

        .container {
            max-width: 600px;
            margin: 100px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            /* Add an overlay to make text more readable */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            font-size: 32px;
            /* Bigger font size for WELCOME */
            font-weight: bold;
            /* Bolded WELCOME */
            color: #333;
        }

        .clock {
            text-align: center;
            font-size: 18px;
            color: black;
            font-weight: bold;
            margin-top: 15px;
            /* Adjusted margin */
        }

        .buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin-top: 20px;
        }

        .round-button {
            width: 100px;
            height: 40px;
            border-radius: 5%;
            background-color: white;
            opacity: 0.6;

            color: black;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            cursor: pointer;
            align-items: center;
            font-style: normal;
            font-weight: bold;
            margin-top: 30px;
            margin-bottom: -90px;

        }

        button {
            font-size: 18px;
            padding: 20px;
            width: 45%;
            margin-bottom: 20px;
            cursor: pointer;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .key-in,
        .key-out,
        .absent,
        .history {
            background-color: #3498db;
            color: white;
        }

        .small-button {
            font-size: 14px;
            padding: 10px;
            margin-top: 5px;

            background-color: #56d660;
            /* Adjust as needed */
        }

        .history,
        #absent-reason-input {
            display: none;
        }

        textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .center-container {
            text-align: center;
            margin-top: -50px;
        }

        .narrow-button {
            width: 250px;
            opacity: 0.7;
            font-weight: bold;
        }

        .narrow-button1 {
            width: 250px;
            opacity: 0.9;
            margin-bottom: 20px;
            background-color: #e61c1c;
        }
    </style>
    <title>Attendance System</title>
</head>

<body>
    <div class="container">
        <div class="header">
            WELCOME <?= $_SESSION["name"] ?>
        </div>

        <div class="clock" id="clock"></div>
        <?php if (isset($error)) : ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>
        <?php if (isset($success)) : ?>
            <p style="color: green;"><?php echo $success; ?></p>
        <?php endif; ?>
        <br>

        <center>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="current-password">Current Password:</label>
                <br>
                <input type="password" id="current-password" name="current-password">
                <br>
                <br>
                <label for="new-password">New Password:</label>
                <br>
                <input type="password" id="new-password" name="new-password">
                <br>
                <br>
                <label for="confirm-new-password">Confirm New Password:</label>
                <br>
                <input type="password" id="confirm-new-password" name="confirm-new-password">
                <br>
                <br>
                
                <button type="submit" name="change-password" class="small-button">Change Password</button>
            </form>
        </center>

    </div>

    <div class="center-container">
        <button type="button" role="button" aria-haspopup="true" aria-expanded="false" onclick="window.location.href='dashboardstaff.php'" class="narrow-button1">
            Back
        </button>
        <br>
        <button type="button" role="button" aria-haspopup="true" aria-expanded="false" onclick="confirmLogout()" class="narrow-button">
            Log Out
        </button>
    </div>

    <script>
        function changePassword() {
            // Add your logic to handle password change
        }

        function confirmLogout() {
            var result = confirm("Are you sure to log out?");
            if (result) {
                // Jika pengguna menekan "Yes", arahkan ke logout.php
                window.location.href = "logout.php";
            } else {
                // Jika pengguna menekan "No" atau menutup popup, tidak lakukan apa-apa
            }
        }





        // Clock functionality
        function updateClock() {
            const now = new Date();
            let hours = now.getHours();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12 || 12; // Convert to 12-hour format
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            document.getElementById('clock').innerText = `${hours}:${minutes}:${seconds} ${ampm}`;
        }

        // Update the clock every second
        setInterval(updateClock, 1000);
    </script>

</body>

</html>