<?php session_start();
date_default_timezone_set('Asia/Kuala_Lumpur');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tarikhSahaja = date("Y-m-d");
    $masaSahaja = date("h:i:s A");



    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["key-in"])) {
        require '../DB/db.php';

        $location = $_POST["location"];
        $query = "INSERT INTO history (h_staffID,h_staffName, h_clock_In, h_date, h_status, h_location) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $status = "Present";
        $tarikhSahaja = date("Y-m-d");
        $masaSahaja = date("h:i:s A");
        $stmt->bind_param("ssssss", $_SESSION["staffid"], $_SESSION["name"], $masaSahaja, $tarikhSahaja, $status, $location);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        $success = "keyed in at " . $masaSahaja;
    }

    if (isset($_POST["key-out"])) {
        require '../DB/db.php';
        $locationOut = $_POST["location"];
        $sql = "UPDATE history SET h_clock_Out = ?, h_location_out = ? WHERE h_staffID = ? AND h_staffName = ? AND h_clock_Out IS NULL ORDER BY h_date DESC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $statusOut = "Present";
        $tarikhSahajaOut = date("Y-m-d");
        $masaSahajaOut = date("h:i:s A");
        $stmt->bind_param("ssss", $masaSahajaOut, $locationOut, $_SESSION["staffid"], $_SESSION["name"]);
        $stmt->execute();
        $stmt->close();
        $conn->close();

        $success = "keyed out at " . $masaSahajaOut;
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"]) && isset($_POST["absent-reason"])) {
        require '../DB/db.php';

        $reason = $_POST["absent-reason"];

        
        function upload()
        {

            $namaFile = $_FILES['supporting-documents']['name'];
            $fileSize = $_FILES['supporting-documents']['size'];
            $error = $_FILES['supporting-documents']['error'];
            $tmpName = $_FILES['supporting-documents']['tmp_name'];

            $ekstensionGambarValid = 'pdf';
            $ekstensionGambar = explode('.', $namaFile);
            $ekstensionGambar = strtolower(end($ekstensionGambar));

            if ($ekstensionGambar !== $ekstensionGambarValid) {
                $notPdf = 'a';
                return  $notPdf;
            }
            $tarikhSahaja = date("Y-m-d");

            $namaFileBaru = 'ABSENT-' . $_SESSION["name"] . '-' . $tarikhSahaja . '.' . $ekstensionGambar;

            $tmpName1 = $_FILES['supporting-documents']['tmp_name'];

            $targetPath2 = '../uploads' . $namaFileBaru;

            if (!move_uploaded_file($tmpName1, $targetPath2)) {
                die('ERROR,CONTACT ADMIN!');
            }

            return $namaFileBaru;
        }

        $supportingDocumentContent = upload();

        if ($supportingDocumentContent != 'a') {
            $sql = "INSERT INTO history (h_staffID, h_staffName, h_reason, h_date, h_status, h_supportingD) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            // "Absent" status for Absent submission
            $status = "Absent";

            $stmt->bind_param("ssssss", $_SESSION["staffid"], $_SESSION["name"], $reason, $tarikhSahaja, $status, $supportingDocumentContent);

            $stmt->execute();

            $stmt->close();

            $success = "Absence Recorded at " . $masaSahaja;
        } else {
            $notpdf = true;
        }
    }
}
require '../DB/db.php';

$h_staffID = $_SESSION["staffid"];
$sql = "SELECT * FROM history WHERE h_staffID = ? ORDER BY h_id DESC";
$stmt = $conn->prepare($sql);

// Bind the parameter
$stmt->bind_param("s", $h_staffID);

// Execute the prepared statement
$stmt->execute();

// Get the result set
$result = $stmt->get_result();

// Fetch the data into an associative array
$rows = [];
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}

// Close the statement
$stmt->close();


require '../DB/db.php';

$h_staffID = $_SESSION["staffid"];

// Fetch shift name from the user table based on staff ID
$userSql = "SELECT u_Shift FROM user WHERE u_staff_ID = ?";
$userStmt = $conn->prepare($userSql);
$userStmt->bind_param("s", $h_staffID);
$userStmt->execute();
$userResult = $userStmt->get_result();
$userData = $userResult->fetch_assoc();
$userStmt->close();

if ($userData) {
    $userShiftName = $userData['u_Shift'];

    // Fetch shift details from the shift table based on shift name
    $shiftSql = "SELECT * FROM shifts WHERE s_Name = ?";
    $shiftStmt = $conn->prepare($shiftSql);
    $shiftStmt->bind_param("s", $userShiftName);
    $shiftStmt->execute();
    $shiftResult = $shiftStmt->get_result();
    $shiftData = $shiftResult->fetch_assoc();
    $shiftStmt->close();
} else {
    // Handle the case where user data (including shift name) is not found
    $shiftData = null;
}

// Fetch history data for the staff member
$historySql = "SELECT * FROM history WHERE h_staffID = ? ORDER BY h_id DESC";
$historyStmt = $conn->prepare($historySql);
$historyStmt->bind_param("s", $h_staffID);
$historyStmt->execute();
$historyResult = $historyStmt->get_result();

// Fetch the data into an associative array
$rows = [];
while ($row = $historyResult->fetch_assoc()) {
    $rows[] = $row;
}

$historyStmt->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('../../images/backg.jpg');
            /* Replace with the path to your background image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            /* Fixed to prevent scrolling */
        }

        .container {
            max-width: 600px;
            margin: 100px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            /* Add an overlay to make text more readable */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            font-size: 32px;
            /* Bigger font size for WELCOME */
            font-weight: bold;
            /* Bolded WELCOME */
            color: #333;
        }

        .clock {
            text-align: center;
            font-size: 18px;
            color: black;
            font-weight: bold;
            margin-top: 15px;
            /* Adjusted margin */
        }

        .buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin-top: 20px;
        }

        .round-button {
            width: 100px;
            height: 40px;
            border-radius: 5%;
            background-color: white;
            opacity: 0.6;

            color: black;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            cursor: pointer;
            align-items: center;
            font-style: normal;
            font-weight: bold;
            margin-top: 30px;
            margin-bottom: -90px;

        }




        button {
            font-size: 18px;
            padding: 20px;
            width: 45%;
            margin-bottom: 20px;
            cursor: pointer;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .key-in {
            background-color: #3498db;
            color: white;
        }

        .key-out {
            background-color: #3498db;
            color: white;
        }

        .absent {
            background-color: #e74c3c;
            color: white;
        }



        .small-button {
            font-size: 14px;
            padding: 10px;
            margin-top: 5px;
            /* Adjust as needed */
        }

        .history {
            background-color: #f39c12;
            color: white;
        }

        #absent-reason-input {
            display: none;
            margin-top: 20px;
        }

        textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        @media screen and (max-width: 600px) {
            button {
                width: 100%;
            }
        }
    </style>
    <title>Attendance System</title>
</head>

<body>
    <div class="container">
        <div class="header">
            WELCOME <?= $_SESSION["name"] ?>
        </div>

        <div class="clock" id="clock"></div>
        <br>
        <div id="shift-info">
            <center>
                <?php
                // Display shift information label
                if ($shiftData) {
                    $shiftLabel = ' Shift Start: <b>' . $shiftData['s_Start'] . ' AM</b>. Shift End: <b>' . $shiftData['s_End'] . ' PM</b> ';

                    echo '<center><b>' . $shiftData['s_ShiftType'] . '</b></center>';
                    echo $shiftLabel;
                } else {
                    echo 'Shift information not available.';
                }
                ?>
            </center>
        </div>

        <div class="buttons">
            <form action="" method="POST" onsubmit="handleFormSubmit()">
                <?php if (isset($success)) : ?>
                    <center>
                        <p style="color: green;"><?php echo $success; ?></p>
                    </center>
                <?php endif; ?>
                <?php if (isset($notpdf)) : ?>
                    <center>
                        <p style="color: red;"><b><?php echo 'Only PDF file accepted!'; ?></b></p>
                    </center>
                <?php endif; ?>
                <center>
                    <button type="submit" name="key-in" id="key-in" class="key-in" onclick="handleClick('key-in')">Key IN</button>
                    <input type="hidden" name="location" id="location">
                    <button type="submit" name="key-out" id="key-out" class="key-out" onclick="handleClick('key-out')">Key OUT</button>
                    <button type="button" name="absent"  class="absent" onclick="handleAbsentClick()">Absent</button>
                    <button type="button" name="history" class="history" onclick="showHistory()">History</button>
                </center>

            </form>

        </div>

        <div id="absent-reason-input">
            <label for="absent-reason">Reason for Absence:</label>
            <form action="" method="POST" enctype="multipart/form-data" onsubmit="handleFormSubmit()">
                <textarea id="absent-reason" name="absent-reason" rows="4" placeholder="Enter reason"></textarea>
                <label for="supporting-documents">Supporting Documents:</label>
                <input type="file" id="supporting-documents" name="supporting-documents">
                <button type="submit" name="submit" id="absent" class="small-button">Submit</button>
            </form>
        </div>
        <div id="history-table-container"></div>
    </div>


    <style>
        .center-container {
            text-align: center;
            margin-top: -50px;
        }

        .narrow-button {
            width: 250px;
            opacity: 0.7;


            font-weight: bold;

        }

        .narrow-button1 {
            width: 250px;
            opacity: 0.7;
            margin-bottom: 20px;

        }
    </style>

    <div class="center-container">
        <button type="button" role="button" aria-haspopup="true" aria-expanded="false" onclick="window.location.href='profile.php'" class="narrow-button1">
            Change Password
        </button>
        <br>
        <button type="button" role="button" aria-haspopup="true" aria-expanded="false" onclick="confirmLogout()" class="narrow-button">
            Log Out
        </button>
    </div>


    <script>
        function getLocation() {
            navigator.geolocation.getCurrentPosition(showPosition, showError);
        }

        function showError(error) {
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    console.error('User denied the request for geolocation.');
                    break;
                case error.POSITION_UNAVAILABLE:
                    console.error('Location information is unavailable.');
                    break;
                case error.TIMEOUT:
                    console.error('The request to get user location timed out.');
                    break;
                case error.UNKNOWN_ERROR:
                    console.error('An unknown error occurred.');
                    break;
            }
        }

        function showPosition(position) {
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude;
            var combinedLocation = latitude.toFixed(6) + ',' + longitude.toFixed(6);
            document.querySelector('#location').value = combinedLocation;
        }

        getLocation();

        function confirmLogout() {
            var result = confirm("Are you sure to log out?");
            if (result) {
                // Jika pengguna menekan "Yes", arahkan ke logout.php
                window.location.href = "logout.php";
            } else {
                // Jika pengguna menekan "No" atau menutup popup, tidak lakukan apa-apa
            }
        }


        function handleFormSubmit() {
            const confirmationMessage = confirm("Are you sure you want to perform this action?");
            if (!confirmationMessage) {
                document.getElementById('key-in').disabled = true; 
                document.getElementById('key-out').disabled = true;
                document.getElementById('absent').disabled = true; // Disable Key IN button
                return true; // Allow form submission
            } else {
                return false; // Cancel form submission
            }
        }

        function handleClick(onsubmit) {
            if (onsubmit == 'key-in') {
                document.getElementById('key-in').style.display = 'none'; // Enable Key IN button when Key OUT is clicked
            }
            if (onsubmit == 'key-out') {
                document.getElementById('key-in').style.display = 'block'; // Enable Key IN button when Key OUT is clicked
            }
        }

        function handleAbsentClick() {
            document.getElementById('history-table-container').style.display = 'none';
            document.getElementById('absent-reason-input').style.display = 'block';



        }



        function showHistory() {
            const historyTable1 = document.getElementById('history-table-container');
            historyTable1.innerHTML = '';
            document.getElementById('history-table-container').style.display = 'block';
            const historyTableContainer = document.getElementById('history-table-container');
            const historyTable = document.createElement('table');
            historyTable.innerHTML = `
            <div id="history">
            <thead id="a1">
                <tr>
                    <th>Name</th>
                    <th>ID</th>
                    <th>Key In Time</th>
                    <th>Key Out Time</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody id="a2">

            <?php foreach ($rows as $row) : ?>
                
                <tr>
                    <td><?php echo htmlspecialchars($row['h_staffName']); ?></td>
                    <td><?php echo htmlspecialchars($row['h_staffID']); ?></td>
                    <td><?php echo htmlspecialchars($row['h_clock_In']); ?></td>
                    <td><?php echo htmlspecialchars($row['h_clock_Out']); ?></td>
                    <td><?php echo htmlspecialchars($row['h_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['h_status']); ?></td>
                </tr>
            

        <?php endforeach; ?>              
            </tbody>
            </div>
        `;
            historyTableContainer.appendChild(historyTable);
            document.getElementById('absent-reason-input').style.display = 'none';
        }

        // Clock functionality
        function updateClock() {
            const now = new Date();
            let hours = now.getHours();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12 || 12; // Convert to 12-hour format
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            document.getElementById('clock').innerText = `${hours}:${minutes}:${seconds} ${ampm}`;
        }

        // Update the clock every second
        setInterval(updateClock, 1000);
    </script>

</body>

</html>