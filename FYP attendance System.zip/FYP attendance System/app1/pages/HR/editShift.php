<?php
// Include your database connection
require '../DB/db.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["s_id"])) {
    $shiftId = $_GET["s_id"];

    // Fetch data from the "user" table for the specified user_id
    $sql = "SELECT s_id, s_Name, s_Start, s_End, s_ShiftType FROM shifts WHERE s_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $shiftId);
    $stmt->execute();
    $stmt->bind_result($s_id, $s_Name, $s_Start, $s_End, $s_ShiftType);
    $stmt->fetch();
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["save"])) {
    // Retrieve form data
    $shiftName = $_POST["shiftName"];
    $shiftStart = $_POST["shiftStart"];
    $shiftEnd = $_POST["shiftEnd"];
    $shiftType = $_POST["shiftType"];
    $shiftId = $_GET["s_id"];
    // Update the user data in the database
    $sql = "UPDATE shifts SET s_Name = ?, s_Start = ?, s_End = ?, s_ShiftType = ? WHERE s_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $shiftName, $shiftStart, $shiftEnd, $shiftType, $shiftId);
    $stmt->execute();
    $stmt->close();
    // Redirect the user to another page after successful update
    header("Location: shifts.php");
}
?>

<?php require "defaults/header.php" ?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">SHIFT MANAGEMENT </h3>
    <br>
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">
                <p class="text-uppercase text-muted small"><strong>EDIT SHIFT</strong>
                </p>
                <div class="row">
                    <div class="col-md-12">
                        <?php if (isset($success)) : ?>
                            <p style="color: green;"><?php echo $success; ?></p>
                        <?php endif; ?>
                        <form class="form-horizontal" action="" method="POST">
                            <div class="form-group">
                                <label for="shiftName" class="col-sm-2 control-label">Shift Name:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="shiftName" name="shiftName" placeholder="Enter Shift Name" value="<?php echo $s_Name; ?>">
                                 </div>
                            </div>
                            <div class=" form-group">
                                    <label for="shiftStart" class="col-sm-2 control-label">Shift Start:</label>
                                    <div class="col-sm-10">
                                        <input type="time" class="form-control" id="shiftStart" name="shiftStart" value="<?php echo $s_Start; ?>">
                                    </div>
                            </div>
                            <div class=" form-group">
                                        <label for="shiftEnd" class="col-sm-2 control-label">Shift End:</label>
                                        <div class="col-sm-10">
                                            <input type="time" class="form-control" id="shiftEnd" name="shiftEnd" value="<?php echo $s_End; ?>">
                                </div>
                            </div>
                            <div class=" form-group">
                                            <label for="shiftType" class="col-sm-2 control-label">Shift Type:</label>
                                            <div class="col-sm-10">
                                                <select class="form-control" id="shiftType" name="shiftType">
                                                    <option value="Weekdays" <?php echo ($s_ShiftType == "Weekdays") ? "selected" : ""; ?>>Weekdays</option>
                                                    <option value="Weekends" <?php echo ($s_ShiftType == "Weekends") ? "selected" : ""; ?>>Weekends</option>
                                                </select>
                                            </div>
                            </div>
                            <div class="form-group">
                                 <div class="col-sm-6">
                                     <button type="submit" class="btn btn-success" id="save"name="save">Edit</button>
                                     <a type="button" class="btn btn-danger" href="shifts.php">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php require "defaults/footer.php" ?>