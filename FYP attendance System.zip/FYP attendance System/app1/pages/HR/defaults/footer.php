<footer id="main_footer">
	        	 
	        </footer>
            </div>
        </div>
    </div>
    <script>
    function confirmLogout() {
        var result = confirm("Are you sure to log out?");
        if (result) {
            // Jika pengguna menekan "Yes", arahkan ke logout.php
            window.location.href = "logout.php";
        } else {
            // Jika pengguna menekan "No" atau menutup popup, tidak lakukan apa-apa
        }
    }
</script>
    <!-- jQuery -->
    <script src='../../../bower_components/jquery/dist/jquery.min.js'></script>

    <!-- Bootstrap Core JavaScript -->
    <script src='../../../bower_components/bootstrap/dist/js/bootstrap.min.js'></script>
    

    <!-- Metis Menu Plugin JavaScript -->
    <script src='../../../bower_components/metisMenu/dist/metisMenu.min.js'></script>

    <!-- Custom Theme JavaScript -->
    <script src='../../scripts/sumea-custom.js'></script>

    <script src='../../../../bower_components/chartist/dist/chartist.js'></script>
    <script src='../../../scripts/chartist-settings.js'></script>

    <script src='../../bower_components/DataTables-1.10.7/media/js/jquery.dataTables.min.js'></script>
    <script src='../../bower_components/datatables-bootstrap3-plugin/media/js/datatables-bootstrap3.js'></script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function () {
            $('#example').dataTable();
        });
    </script>

</body>

</html>