<?php session_start();
require "defaults/header.php";

require '../DB/db.php';

function getUserCount($conn, $roles)
{
    $rolesPlaceholder = implode(',', array_fill(0, count($roles), '?'));
    $sql = "SELECT COUNT(*) AS count FROM user WHERE u_role IN ($rolesPlaceholder)";
    $stmt = $conn->prepare($sql);

    // Binding parameters dynamically based on the number of roles
    $types = str_repeat('s', count($roles));
    $stmt->bind_param($types, ...$roles);

    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['count'];
}

function getShiftCount($conn)
{
    $sql = "SELECT COUNT(*) AS count FROM shifts";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['count'];
}

function getAttendanceCount($conn, $status)
{
    date_default_timezone_set('Asia/Kuala_Lumpur');
    // Assuming h_datetime is a datetime column and contains both date and time
    $todayDate = date('Y-m-d');
    $sql = "SELECT COUNT(*) AS count FROM history WHERE h_status = ? AND DATE(h_date) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $status, $todayDate);
    $stmt->execute();
    $result = $stmt->get_result();

    $row = $result->fetch_assoc();

    // If there is no entry for the current date, set count to 0
    return ($row !== null) ? $row['count'] : 0;
}
// Get counts for different roles
$totalEmployees = getUserCount($conn, ['Operator', 'Supervisor']);
$totalShifts = getShiftCount($conn);

// Get counts for today's attendance
$totalPresentToday = getAttendanceCount($conn, 'Present');
$totalAbsentToday = getAttendanceCount($conn, 'Absent');

$conn->close();
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<div id="page-wrapper">
    <h3 class="text-center margin-top-none">WELCOME <?= $_SESSION["name"] ?> </h3>
    <br>
    <div class="row">
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h5 class="margin-top-none"><span class="label label-success pull-right">Employee's</span></h5>
                    <h1 class="text-center"><?= $totalEmployees ?></h1>
                    <p class="small text-muted text-center">Total Employee</p>
                </div>
                <div class="panel-footer"><span class="text-success pull-right"><i class=""></i></span>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h5 class="margin-top-none"><span class="label label-success pull-right">Shifts</span></h5>
                    <h1 class="text-center"><?= $totalShifts ?></h1>
                    <p class="small text-muted text-center">Total Shifts</p>
                </div>
                <div class="panel-footer"><span class="text-success pull-right"><i class=""></i></span>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h5 class="margin-top-none"><span class="label label-success pull-right">Present</span></h5>
                    <h1 class="text-center"><?= $totalPresentToday ?></h1>
                    <p class="small text-muted text-center">Total Present Today</p>
                </div>
                <div class="panel-footer"><span class="text-success pull-right"><i class=""></i></span>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h5 class="margin-top-none"><span class="label label-success pull-right">Absent</span></h5>
                    <h1 class="text-center"><?= $totalAbsentToday ?></h1>
                    <p class="small text-muted text-center">Total Absent Today</p>
                </div>
                <div class="panel-footer"><span class="text-success pull-right"><i class=""></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <canvas id="donutChart" width="300" height="300" style="margin: auto;"></canvas>
            </div>
        </div>
    </div>



</div>
<script>
    // Assuming you have the data available
    var presentPercentage = <?= ($totalPresentToday / $totalEmployees) * 100 ?>;
    var absentPercentage = <?= ($totalAbsentToday / $totalEmployees) * 100 ?>;

    // Create a donut chart
    var ctx = document.getElementById('donutChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Present', 'Absent'],
            datasets: [{
                data: [presentPercentage, absentPercentage],
                backgroundColor: ['#1ad65c', '#e84646']
            }]
        },
        options: {
            cutoutPercentage: 50, // Adjust this value to control the size of the hole in the middle
            responsive: true,
            legend: {
                position: 'bottom',
            },
            title: {
                display: true,
                text: 'Attendance Today (%)'
            }
        }
    });
</script>

<?php require "defaults/footer.php" ?>