<?php

// Include your database connection
require '../DB/db.php';

// Fetch data from the "user" table
$sql = "SELECT u_id, u_Name, u_staff_ID, u_role, u_Shift ,u_IC_Number FROM user WHERE u_role='Operator' || u_role='Supervisor'";
$result = $conn->query($sql);



require '../DB/db.php';

// Fetch data from the "user" table
$sql = "SELECT * FROM history WHERE h_staffID = ? ORDER BY h_id DESC";
$stmt = $conn->prepare($sql);

?>


<?php require "defaults/header.php" ?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">LIST OF EMPLOYEE'</h3>
    <br>
    <div class="row">

        <br>
        <div class="col-md-6">
            <input type="text" class="form-control" id="searchInput" placeholder="Search by Name">
        </div>
        <br>
        <br>
        <br>
        
        <div class="panel panel-default mt-5">
        <table class="table table-striped">
            <table id="attendance-table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <colgroup>
                    <col style="width: 5%;">
                    <col style="width: 20%;">
                    <col style="width: 10%;">
                    <col style="width: 10%;">
                    <col style="width: 10%;">
                    <col style="width: 6%;">
                    <col style="width: 15%;">
                </colgroup>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Employee Name</th>
                        <th>ID</th>
                        <th>IC Number</th>
                        <th>Role</th>
                        <th>Shift</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                $i=1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<th scope='row'>" . $i . "</th>";
                    echo "<td>" . $row["u_Name"] . "</td>";
                    echo "<td>" . $row["u_staff_ID"] . "</td>";
                    echo "<td>" . $row["u_IC_Number"] . "</td>";
                    echo "<td>" . $row["u_role"] . "</td>";
                    echo "<td>" . $row["u_Shift"] . "</td>";
                    $id = $row['u_staff_ID'];
                    echo "<td>
                    <a href='editUser.php?u_id=" . $row["u_id"] . "' class='btn btn-sm btn-warning'>
                            Edit
                        </a>
                    <a href='exportData.php?id=$id'  class='btn btn-primary'>View History</a>
                            </td>";
                            echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No records found</td></tr>";
            }
            ?>
        </tbody>
            </table>
        </div>
    </div>
</div>
<?php require "defaults/footer.php" ?>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.5/xlsx.full.min.js"></script>
<script type="text/javascript">
    function exportToExcel() {
        /* Get table data */
        var table = document.getElementById("attendance-table");
        var ws = XLSX.utils.table_to_sheet(table);

        /* Style for header row (bold) */
        var headerStyle = {
            font: { bold: true },
            alignment: { horizontal: 'center' } // Center-align the text
        };
        XLSX.utils.format_cell(ws['A1'], headerStyle);
        XLSX.utils.format_cell(ws['B1'], headerStyle);
        XLSX.utils.format_cell(ws['C1'], headerStyle);
        XLSX.utils.format_cell(ws['D1'], headerStyle);
        XLSX.utils.format_cell(ws['E1'], headerStyle);
        XLSX.utils.format_cell(ws['F1'], headerStyle);
        XLSX.utils.format_cell(ws['G1'], headerStyle);

        /* Set column widths (character width multiplied by a factor) */
        var colWidths = [
            { wch: 5 },  // No
            { wch: 20 }, // Staff Name
            { wch: 10 }, // ID
            { wch: 15 }, // IC Number
            { wch: 15 }, // Role
            { wch: 15 }, // Shift
            { wch: 15 }  // Action
        ];
        ws['!cols'] = colWidths;

        /* Create Excel file and download */
        var wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Attendance History");
        XLSX.writeFile(wb, 'user_history.xlsx');
    }

    document.getElementById("searchInput").addEventListener("input", function () {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toLowerCase(); // Convert search query to lowercase
        table = document.getElementById("attendance-table");
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows, and show/hide those that match the search query
        for (i = 1; i < tr.length; i++) {  // Start from 1 to skip the table header row
            td = tr[i].getElementsByTagName("td")[0]; // Index 1 corresponds to the 'Employee Name' column
            if (td) {
                txtValue = td.textContent || td.innerText;
                
                // Convert text content to lowercase for case-insensitive comparison
                var lowerCaseTxtValue = txtValue.toLowerCase();

                // Use a regular expression for partial matching
                var regex = new RegExp(filter, 'i');
                if (lowerCaseTxtValue.match(regex)) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    });

</script>