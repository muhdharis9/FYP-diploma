<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["save"])) {

    require '../DB/db.php';
    // Retrieve form data
    $shiftName = $_POST["shiftName"];
    $shiftStart = $_POST["shiftStart"];
    $shiftEnd = $_POST["shiftEnd"];
    $shiftType = $_POST["shiftType"];

    $shiftStart = date("g:i A", strtotime($shiftStart));
    $shiftEnd = date("g:i A", strtotime($shiftEnd));
    
    $sql = "INSERT INTO shifts (s_Name,s_Start,s_End,s_ShiftType) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $shiftName, $shiftStart, $shiftEnd, $shiftType);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    $success = "Shift Successfully added";
}
?>


<?php require "defaults/header.php" ?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">SHIFT MANAGEMENT </h3>
    <br>
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">
                <p class="text-uppercase text-muted small"><strong>New Shift</strong>
                </p>
                <div class="row">
                    <div class="col-md-12">
                        <?php if (isset($success)) : ?>
                            <p style="color: green;"><?php echo $success; ?></p>
                        <?php endif; ?>
                        <form class="form-horizontal" action="" method="POST">
                            <div class="form-group">
                                <label for="shiftName" class="col-sm-2 control-label">Shift Name:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="shiftName" name="shiftName" placeholder="Enter Shift Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="shiftStart" class="col-sm-2 control-label">Shift Start:</label>
                                <div class="col-sm-10">
                                    <input type="time" class="form-control" id="shiftStart" name="shiftStart">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="shiftEnd" class="col-sm-2 control-label">Shift End:</label>
                                <div class="col-sm-10">
                                    <input type="time" class="form-control" id="shiftEnd" name="shiftEnd">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="shiftType" class="col-sm-2 control-label">Shift Type:</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="shiftType" name="shiftType">
                                        <option>Weekdays</option>
                                        <option>Weekends</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-6">
                                    <button type="submit" class="btn btn-success" name="save">Save</button>
                                    <a type="button" class="btn btn-danger" href="shifts.php">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php require "defaults/footer.php" ?>