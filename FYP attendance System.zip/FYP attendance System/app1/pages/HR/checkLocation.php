<?php

$location = isset($_GET['location']) ? urldecode($_GET['location']) : 'default_value_if_not_set';

// Split the location string into latitude and longitude
$coordinates = explode(',', $location);
$lat = isset($coordinates[0]) ? $coordinates[0] : 'default_latitude';
$lng = isset($coordinates[1]) ? $coordinates[1] : 'default_longitude';

require "defaults/header.php"

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Location</title>
    <!-- Include Leaflet CSS and JavaScript -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <style>
        /* Set the map container height */
        #map {
            height: 400px;
        }
    </style>
</head>

<div id="page-wrapper">
<h3 class="text-center margin-top-none">CHECK LOCATION</h3>
    <br>
    <a type="button" class="btn btn-danger" href="attendHistory.php">Back</a>
    <div id="map"></div>

    <script>
        // Function to initialize the map
        function initMap() {
            // Latitude and Longitude coordinates from the URL parameters
            var myLatLng = [<?php echo $lat; ?>, <?php echo $lng; ?>];

            // Create a map centered at the specified coordinates
            var map = L.map('map').setView(myLatLng, 15);

            // Add a tile layer from OpenStreetMap
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);

            // Add a marker at the specified coordinates
            L.marker(myLatLng).addTo(map)
                .bindPopup('Location: <?php echo $lat; ?>, <?php echo $lng; ?>')
                .openPopup();
        }

        // Load the map when the page has finished loading
        window.onload = function() {
            initMap();
        };
    </script>
</div>
<br>
<br>


</html>








<?php require "defaults/footer.php" ?>