<?php
// Include your database connection
require '../DB/db.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["u_id"])) {
    $user_id = $_GET["u_id"];

    // Fetch data from the "user" table for the specified user_id
    $sql = "SELECT u_id, u_Name, u_staff_ID, u_role, u_IC_Number, u_Shift, u_Password FROM user WHERE u_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($u_id, $u_Name, $u_staff_ID, $u_role, $u_IC_Number, $u_Shift, $u_Password);
    $stmt->fetch();
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["save"])) {

    // Retrieve form data
    $name = $_POST["name"];
    $position = $_POST["position"];
    $icNumber = $_POST["icNumber"];
    $employeeID = $_POST["employeeID"];
    $assignTo = $_POST["assignTo"];
    $password = $_POST["password"];
    // Updated this line
    $user_id = $_GET["u_id"];

    // Validate Name (only alphabets allowed)
    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $error = "Name should contain only alphabets.";
    } else {
        // Convert name to uppercase
        $name = strtoupper($name);
    }

    // Validate IC Number (exactly 12 digits)
    if (!preg_match("/^\d{12}$/", $icNumber)) {
        $error = "IC Number should be exactly 12 digits.";
    }

    // If there are no errors, proceed with database update
    if (!isset($error)) {
        // Include your database connection

        // SQL statement with placeholders
        $sql = "UPDATE user SET u_Name = ?, u_role = ?, u_IC_Number = ?, u_staff_ID = ?, u_Shift = ?, u_Password = ? WHERE u_id = ?";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("ssssssi", $name, $position, $icNumber, $employeeID, $assignTo, $password, $user_id);

        // Execute the prepared statement
        $stmt->execute();

        // Close the statement
        $stmt->close();

        // Close the database connection
        $conn->close();

        // Optionally, redirect the user to another page after successful update
        header("Location: DisplayEmp.php");
    }
}



require '../DB/db.php';
$sqlShifts = "SELECT s_ShiftType , s_Name FROM shifts";
$resultShifts = $conn->query($sqlShifts);

// Check for errors during query execution
if (!$resultShifts) {
    die("Error: " . $conn->error);
}

?>

<?php require "defaults/header.php" ?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">EDIT USER</h3>
    <br>
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">
                <p class="text-uppercase text-muted small"><strong>Edit User</strong></p>
                <div class="row">
                    <div class="col-md-12">
                        <?php if (isset($error)) : ?>
                            <p style="color: red;"><?php echo $error; ?></p>
                        <?php endif; ?>

                        <?php if (isset($success)) : ?>
                            <p style="color: green;"><?php echo $success; ?></p>
                        <?php endif; ?>
                        <form class="form-horizontal" action="" method="POST">
                            <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Name:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" value="<?php echo $u_Name; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="position" class="col-sm-2 control-label">Position:</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="position" name="position">
                                        <option <?php if ($u_role == 'Operator') echo 'selected'; ?>>Operator</option>
                                        <option <?php if ($u_role == 'Supervisor') echo 'selected'; ?>>Supervisor</option>
                                        <option <?php if ($u_role == 'HR') echo 'selected'; ?>>HR</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="icNumber" class="col-sm-2 control-label">IC Number:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="icNumber" name="icNumber" placeholder="Enter IC Number" value="<?php echo $u_IC_Number; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="employeeID" class="col-sm-2 control-label">Employee ID:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="employeeID" name="employeeID" placeholder="Enter Employee ID" value="<?php echo $u_staff_ID; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="assignTo" class="col-sm-2 control-label">Assign to:</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="assignTo" name="assignTo">
                                        <?php
                                        // Check if there are rows in the result set
                                        if ($resultShifts->num_rows > 0) {
                                            // Output data of each row
                                            while ($rowShift = $resultShifts->fetch_assoc()) {
                                                // Use shift_id as the value and shift_name as the display text for each option
                                                $selected = ($rowShift["s_Name"] == $u_Shift) ? 'selected' : '';
                                                echo "<option value='" . $rowShift["s_Name"] . "' $selected>" . $rowShift["s_Name"] . "</option>";
                                            }
                                            echo "<option value='NONE' " . ($u_Shift == 'NONE' ? 'selected' : '') . ">NONE</option>";
                                        } else {
                                            echo "<option>No shifts available</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password" class="col-sm-2 control-label">Password:</label>
                                <div class="col-sm-10">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" value="<?php echo $u_Password; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-6">
                                    <button type="submit" class="btn btn-success" id="save" name="save">Save</button>
                                    <a type="button" class="btn btn-danger" href="DisplayEmp.php">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require "defaults/footer.php" ?>