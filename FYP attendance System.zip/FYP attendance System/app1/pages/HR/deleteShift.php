<?php

// Include your database connection
require '../DB/db.php';

// Check if the user ID is set in the URL
if (isset($_GET['s_id'])) {
    $shiftId = $_GET['s_id'];
    // SQL statement to delete the user
    $sql = "DELETE FROM shifts WHERE s_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $shiftId); // Assuming u_id is an integer
    $stmt->execute();
    $stmt->close();
    $conn->close();
    header("Location: shifts.php");
    exit();
} else {
    // Handle the case where the user ID is not set in the URL
    echo "Invalid request. User ID not provided.";
    exit();
}
