<?php

// Include your database connection
require '../DB/db.php';

// Fetch data from the "user" table
$sql = "SELECT s_id, s_Name, s_Start, s_End, s_ShiftType FROM shifts";
$result = $conn->query($sql);

?>


<?php require "defaults/header.php"?>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">SHIFT MANAGEMENT</h3>
    <br>
    <div class="row">
        <!--tambahhh siniiiii -->
        <!--tambahhh siniiiii -->
        <!--tambahhh siniiiii -->
        <!--tambahhh siniiiii -->
        <!--tambahhh siniiiii -->

        <a type="button" class="btn btn-primary" href="addShift.php">Add Shifts</a>
        
        <br>
        <br>
        <div class="panel panel-default mt-5">
            <table class="table table-striped">
                <colgroup>
                    <col style="width: 5%;">
                    <col style="width: 20%;">
                    <col style="width: 20%;">
                    
                    <!-- Adjust the width as needed -->
                </colgroup>
                <thead>
                    <tr>

                        <th>#</th>
                        <th>Shift</th>
                        <th>Shift Start</th>
                        <th>Shift End</th>
                        <th>Shift Type</th>
                        <th>Actions</th>
        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        // Output data of each row
                        $i = 1;
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<th scope='row'>" . $i . "</th>";
                            echo "<td>" . $row["s_Name"] . "</td>";
                            echo "<td>" . $row["s_Start"] . "</td>";
                            echo "<td>" . $row["s_End"] . "</td>";
                            echo "<td>" . $row["s_ShiftType"] . "</td>";
                            echo "<td>
                           
                            <a href= editShift.php?s_id=" . $row["s_id"] . "' class='btn btn-sm btn-warning'>
                            Edit
                        </a>
                            <button class='btn btn-sm btn-danger' onclick='deleteUser(" . $row["s_id"] . ")'>
                                Delete
                            </button>
                        </td>";
                            echo "</tr>";
                            $i++;
                        }
                    } else {
                        echo "<tr><td colspan='5'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    function deleteUser(shiftId) {
        var confirmation = confirm("Are you sure you want to delete this shift?");
        if (confirmation) {
            // If the user clicks "OK", redirect to a delete script or perform AJAX delete
            window.location.href = "deleteShift.php? s_id=" + shiftId;
        }
    }
</script>




<?php require "defaults/footer.php"?>