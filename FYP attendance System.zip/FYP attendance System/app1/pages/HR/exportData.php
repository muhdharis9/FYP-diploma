<?php

// Include your database connection
require '../DB/db.php';

// Fetch data from the "user" table
$user_id = $_GET['id'];
$sql = "SELECT * FROM history WHERE h_staffID = ? ORDER BY h_id DESC";
$stmt = $conn->prepare($sql);

// Bind the parameter
$stmt->bind_param("s", $user_id);

// Execute the prepared statement
$stmt->execute();

// Get the result set
$result = $stmt->get_result();

// Fetch the data into an associative array
$rows = [];
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}

// Close the statement
$stmt->close();


?>

<?php require "defaults/header.php" ?>

<style>
    .present {
        color: green;
    }

    .absent {
        color: red;
    }
</style>

<div id="page-wrapper">
    <h3 class="text-center margin-top-none">Attendance History</h3>
    <br>
    <div class="row">

        <a type="button" class="btn btn-danger" href="DisplayEmp.php">Back</a>
        <br>
        <br>
        <a type="button" class="btn btn-primary" onclick="exportToExcel()">Export to Excel</a>
        <br>
        <br>
        <div class="panel panel-default mt-5">
            <table class="table table-striped">
                <table id="attendance-table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <colgroup>
                        <col style="width: 4%;">
                        <col style="width: 20%;">
                        <col style="width: 12%;">
                        <col style="width: 12%;">
                        <col style="width: 12%;">
                        <col style="width: 12%;">
                        <col style="width: 12%;">
                        <col style="width: 15%;">
                        <col style="width: 8%;">
                        <col style="width: 10%;">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Staff Name</th>
                            <th>ID</th>
                            <th>Clock In Time</th>
                            <th>Clock Out Time</th>
                            <th>Date</th> <!-- New column for Date -->
                            <th>Location IN</th>
                            <th>Location OUT</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Supporting Docs</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        // Output data of each row
                        $i = 1;
                        foreach ($rows as $row) : {
                                echo "<tr>";
                                echo "<th scope='row'>" . $i . "</th>";
                                echo "<td>" . $row["h_staffName"] . "</td>";
                                echo "<td>" . $row["h_staffID"] . "</td>";
                                echo "<td>" . $row["h_clock_In"] . "</td>";
                                echo "<td>" . $row["h_clock_Out"] . "</td>";
                                echo "<td>" . $row["h_date"] . "</td>";
                                echo '<td><a href="checkLocation.php?location=' . urlencode($row["h_location"]) . '">' . $row["h_location"] . '</a></td>';
                                echo '<td><a href="checkLocation.php?location=' . urlencode($row["h_location_out"]) . '">' . $row["h_location_out"] . '</a></td>';
                                echo "<td>" . $row["h_reason"] . "</td>";
                                echo "<td>" . $row["h_status"] . "</td>";
                                echo "<td>" . formatSupportingDocumentLink($row['h_supportingD']) . "</td>";
                                echo "</tr>";
                                $i++;
                            }
                        endforeach;
                        function formatSupportingDocumentLink($documentLink) {
                            return ($documentLink) ? '<a href="../uploads' . htmlspecialchars($documentLink) . '" target="_blank">View</a>' : '';
                        }
                        ?>

                       
                    </tbody>
                </table>
        </div>
    </div>
</div>

<?php require "defaults/footer.php" ?>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.5/xlsx.full.min.js"></script>
<script type="text/javascript">
    function exportToExcel() {
        /* Get table data */
        var table = document.getElementById("attendance-table");
        var ws = XLSX.utils.table_to_sheet(table);

        /* Style for header row (bold) */
        var style = {
            font: {
                bold: true
            }
        };
        ws["!rows"] = [{
            cells: [{
                style: style
            }]
        }];

        /* Set column widths (character width multiplied by a factor) */
        var colWidths = [{
                wch: 5
            }, // No
            {
                wch: 20
            }, // Staff Name
            {
                wch: 10
            }, // ID
            {
                wch: 15
            }, // Clock In Time
            {
                wch: 15
            }, // Clock Out Time
            {
                wch: 15
            }, // Date
            {
                wch: 20
            }, // Location
            {
                wch: 20
            }, // Location
            {
                wch: 20
            }, // Reason
            {
                wch: 10
            } // Status
        ];
        ws['!cols'] = colWidths;

        /* Create Excel file and download */
        var wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Attendance History");
        XLSX.writeFile(wb, 'staff_history.xlsx');
    }
</script>