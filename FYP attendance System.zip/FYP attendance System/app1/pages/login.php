<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {

    require 'DB/db.php';
    if (isset($_POST["uid"]) && isset($_POST["pass"])) {

        $staffid = $_POST["uid"];
        $password = $_POST["pass"];
        $sql = "SELECT 	u_id, u_role ,u_Name FROM user WHERE u_staff_ID = ? AND u_Password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $staffid, $password);
        $stmt->execute();
        $stmt->bind_result($dbUsername, $dbRole, $name);
        $stmt->fetch();
        $stmt->close();
        if ($dbUsername) {
            if ($dbRole == "Admin") {
                $_SESSION["name"] = $name;
                $_SESSION["staffid"] = $staffid;
                $_SESSION["u_id"] = $dbUsername;
                header("Location: Admin/index.php");
            } elseif ($dbRole == "HR") {
                $_SESSION["name"] = $name;
                $_SESSION["staffid"] = $staffid;
                $_SESSION["u_id"] = $dbUsername;
                header("Location: HR/index.php");
            }
            if ($dbRole == "Supervisor") {
                $_SESSION["name"] = $name;
                $_SESSION["staffid"] = $staffid;
                $_SESSION["u_id"] = $dbUsername;
                header("Location: Supervisor/dashboardSV.php");

            } elseif ($dbRole == "Operator") {
                $_SESSION["name"] = $name;
                $_SESSION["staffid"] = $staffid;
                $_SESSION["u_id"] = $dbUsername;
                header("Location: Staff/dashboardstaff.php");
            }
        } else {
            $errorMessage = "Invalid username or password. Please contact Admin for further assistance.";
        }
    }
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> - Login</title>
    <link rel="apple-touch-icon" sizes="57x57" href="../favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="../favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="../favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="../favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="../favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="../favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="../favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="../favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="../favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="../favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="../favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="../favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="../favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="../favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#2e353b">
    <meta name="msapplication-TileImage" content="/mstile-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap Core CSS -->
    <link rel='stylesheet' href='../../bower_components/bootstrap/dist/css/bootstrap.min.css'>
    <!-- Custom Fonts Awesome -->
    <link rel='stylesheet' href='font-awesome-4.4.0/css/font-awesome.min.css'>

    <!-- Hammer reload -->
    <script>
        setInterval(function() {
            try {
                if (typeof ws != 'undefined' && ws.readyState == 1) {
                    return true;
                }
                ws = new WebSocket('ws://' + (location.host || 'localhost').split(':')[0] + ':35353')
                ws.onopen = function() {
                    ws.onclose = function() {
                        document.location.reload()
                    }
                }
                ws.onmessage = function() {
                    var links = document.getElementsByTagName('link');
                    for (var i = 0; i < links.length; i++) {
                        var link = links[i];
                        if (link.rel === 'stylesheet' && !link.href.match(/typekit/)) {
                            href = link.href.replace(/((&|\?)hammer=)[^&]+/, '');
                            link.href = href + (href.indexOf('?') >= 0 ? '&' : '?') + 'hammer=' + (new Date().valueOf());
                        }
                    }
                }
            } catch (e) {}
        }, 1000)
    </script>
    <!-- /Hammer reload -->

</head>

<body>
    <div id="wrapper" class="margin-top-15">
        <!-- Page Content -->
        <div id="page-wrapper" class="background-page">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <div class="login-panel panel panel-default">
                            <div class="panel-heading frame logo-center-form" id="container">
                                <h3 class="text-center" style="color: white;"><b>ATTENDANCE SYSTEM</b></h3>
                            </div>
                            <div class="panel-body">
                                <h3 class="text-center"><b>Login</b></h3>
                                <br>
                                <?php if (isset($errorMessage)) : ?>
                                    <p style="color: red;"><?php echo $errorMessage; ?></p>
                                <?php endif; ?>
                                <br>
                                <form action="" method="POST">
                                    <div class="form-group">
                                        <input class="form-control input-lg" placeholder="Enter ID" name="uid">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control input-lg" placeholder="Password" name="pass">
                                    </div>

                                    <button href="index.html" type="submit" name="login" class="current-parent btn btn-block btn-lg btn-success">Login</button>
                                </form>
                            </div>
                            <div class="panel-footer">
                                

                            </div>
                        </div>
                    </div>

                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>

</html>