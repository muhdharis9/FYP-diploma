

    $("#range_25").ionRangeSlider({
    type: "double",
    min: 1000000,
    max: 2000000,
    grid: true
});
        
        $("#range_26").ionRangeSlider({
    type: "double",
    min: 1000000,
    max: 2000000,
    grid: true,
    force_edges: true
});
        
        
$("#range_27").ionRangeSlider({
    type: "double",
    min: 0,
    max: 10000,
    grid: true
});
        
        
$("#range_28").ionRangeSlider({
    type: "double",
    min: 0,
    max: 10000,
    grid: true,
    grid_num: 10
});
        
        
$("#range_29").ionRangeSlider({
    type: "double",
    min: 0,
    max: 10000,
    step: 500,
    grid: true,
    grid_snap: true
});
        
        
$("#range_30").ionRangeSlider({
    type: "single",
    min: 0,
    max: 10,
    step: 2.34,
    grid: true,
    grid_snap: true
});
        
        $("#range_31").ionRangeSlider({
    type: "double",
    min: 0,
    max: 100,
    from: 30,
    to: 70,
    from_fixed: true
});
        
        
$("#range_32").ionRangeSlider({
    type: "double",
    min: 0,
    max: 100,
    from: 30,
    to: 70,
    from_fixed: true,
    to_fixed: true
});
        
        $("#range_35").ionRangeSlider({
    type: "double",
    min: 0,
    max: 100,
    from: 20,
    from_min: 10,
    from_max: 30,
    from_shadow: true,
    to: 80,
    to_min: 70,
    to_max: 90,
    to_shadow: true,
    grid: true,
    grid_num: 10
});
        
        
$("#range_36").ionRangeSlider({
    min: 0,
    max: 100,
    from: 30,
    disable: true
});